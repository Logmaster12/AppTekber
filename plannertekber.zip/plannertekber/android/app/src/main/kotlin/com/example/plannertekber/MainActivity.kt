package com.example.plannertekber

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
